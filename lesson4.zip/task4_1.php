<?php
$arr1 = [41, 25, 36];

$evenOddCheck = function (int $e): string {
  return ($e & 1) ? "нечетное" : "четное"; 
};

$evenOdd=array_map($evenOddCheck, $arr1);
print_r($evenOdd);

