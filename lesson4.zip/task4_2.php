<?php
$mas = [4,78, 67];

$aggrData = function (array $numbers): array{
    
    return [
    'max' => max($numbers),
    'min' => min($numbers),
    'avg' => array_sum($numbers) / count($numbers),
    
    ];
    
};

print_r($aggrData($mas));
